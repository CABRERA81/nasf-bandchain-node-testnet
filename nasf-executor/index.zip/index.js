const https = require("https");

exports.handler = async (event) => {
  try {
    const url = "https://api.coingecko.com/api/v3/simple/price?ids=nash-smart-finance&vs_currencies=usd";

    const responseBody = await new Promise((resolve, reject) => {
      https
        .get(url, (res) => {
          let data = "";
          res.on("data", (chunk) => (data += chunk));
          res.on("end", () => resolve(data));
        })
        .on("error", (err) => reject(err));
    });

    const data = JSON.parse(responseBody);
    const price = data["nash-smart-finance"]?.usd;

    if (!price) {
      throw new Error("No se encontró el precio de NASF");
    }

    // Formato que espera Yoda: codificado en base64
    const payload = {
      price_usd: price
    };

    const base64 = Buffer.from(JSON.stringify(payload)).toString("base64");

    return {
      statusCode: 200,
      body: JSON.stringify({
        responses: [
          {
            result: {
              value: base64,
              pub_key: "placeholder_pubkey",
              signature: "placeholder_signature"
            }
          }
        ]
      })
    };
  } catch (err) {
    console.error("❌ Error en el executor:", err.message);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "No se pudo obtener el precio de NASF" })
    };
  }
};

